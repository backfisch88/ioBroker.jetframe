import type { Aircraft, JetFrameConfig, AdapterLike } from './types';
import { round } from './geo';
import { cacheExternalLogoUrl, MANUFACTURER_LOGO_CACHE_DIR } from './images';

const LAST_SPEECH_TRIGGER: Record<string, string> = {};

// Roles that require common.write = false per ioBroker state-roles spec
// (read-only sensor/indicator values). See:
// https://github.com/ioBroker/ioBroker.docs/blob/master/docs/en/dev/stateroles.md
const READ_ONLY_ROLES = new Set(['value', 'indicator']);

/**
 * Ensure that an intermediate channel/folder object exists for the given id.
 */
export async function ensureChannel(adapter: AdapterLike, id: string, name?: string): Promise<void> {
	const obj = await adapter.getForeignObjectAsync(id);

	if (!obj) {
		await adapter.setForeignObjectAsync(id, {
			type: 'channel',
			common: {
				name: name || id.split('.').pop() || id,
			},
			native: {},
		});
	}
}

/**
 *
 */
export async function ensureState(
	adapter: AdapterLike,
	id: string,
	def: ioBroker.StateValue,
	type: ioBroker.CommonType,
	role: string,
): Promise<void> {
	const obj = await adapter.getForeignObjectAsync(id);
	const desiredWrite = !READ_ONLY_ROLES.has(role);

	if (!obj) {
		await adapter.setForeignObjectAsync(id, {
			type: 'state',
			common: {
				name: id.split('.').pop() || id,
				type,
				role,
				read: true,
				write: desiredWrite,
			},
			native: {},
		});

		await adapter.setForeignStateAsync(id, def, true);
		return;
	}

	// Object already exists (e.g. from before this fix): heal stale metadata
	// (role/type/write) in place without touching the current state value.
	const common = obj.common || {};
	if (common.role !== role || common.type !== type || common.write !== desiredWrite) {
		await adapter.extendForeignObjectAsync(id, {
			common: {
				type,
				role,
				read: true,
				write: desiredWrite,
			},
		});
	}
}

/**
 *
 */
export async function ensureBaseStates(adapter: AdapterLike, config: JetFrameConfig): Promise<void> {
	await ensureState(adapter, `${config.dpRoot}.enabled`, config.enabled !== false, 'boolean', 'switch');

	await adapter.setForeignStateAsync(`${config.dpRoot}.enabled`, config.enabled !== false, true);
	await ensureState(adapter, `${config.dpRoot}.status`, 'init', 'string', 'text');
	await ensureState(adapter, `${config.dpRoot}.lastUpdate`, '', 'string', 'text');
	await ensureState(adapter, `${config.dpRoot}.allCount`, 0, 'number', 'value');
	await ensureState(adapter, `${config.dpRoot}.matchCount`, 0, 'number', 'value');
	await ensureState(adapter, `${config.dpRoot}.clearImageCache`, false, 'boolean', 'button');

	await ensureState(adapter, config.airportJsonDp, '[]', 'string', 'json');
	await ensureState(adapter, `${config.dpRoot}.airportjsonLastUpdate`, '', 'string', 'text');
	await ensureState(adapter, `${config.dpRoot}.specialLiveries`, '[]', 'string', 'json');
	await ensureState(adapter, `${config.dpRoot}.specialLiveriesLastUpdate`, '', 'string', 'text');

	await ensureState(adapter, `${config.dpRoot}.speechMode`, 'browser', 'string', 'text');
	await ensureState(
		adapter,
		`${config.dpRoot}.speechTemplate`,
		'{modeSpeechText}: {airlineName} {bestCallsign} {routeDirectionText} {routeOtherAirport} in {altitudeFt} ft. {windowPositionSpeechText}.',
		'string',
		'text',
	);

	await adapter.setForeignStateAsync(`${config.dpRoot}.speechMode`, config.speechMode || 'browser', true);

	// speechEnabled Master
	try {
		const speechEnabledObj = await adapter.getForeignObjectAsync(`${config.dpRoot}.speechEnabled`);
		if (!speechEnabledObj) {
			await adapter.setForeignObjectAsync(`${config.dpRoot}.speechEnabled`, {
				type: 'state',
				common: {
					name: 'Speech output active',
					type: 'boolean',
					role: 'switch',
					read: true,
					write: true,
					def: true,
				},
				native: {},
			});
		}

		const speechEnabledState = await adapter.getForeignStateAsync(`${config.dpRoot}.speechEnabled`);
		if (speechEnabledState?.val === null || speechEnabledState?.val === undefined) {
			await adapter.setForeignStateAsync(`${config.dpRoot}.speechEnabled`, true, true);
		}
	} catch {
		// ignore
	}
	await adapter.setForeignStateAsync(
		`${config.dpRoot}.speechTemplate`,
		config.speechTemplate ||
			'{modeSpeechText}: {airlineName} {bestCallsign} {routeDirectionText} {routeOtherAirport} in {altitudeFt} ft. {windowPositionSpeechText}.',
		true,
	);

	await ensureFlightStates(adapter, `${config.dpRoot}.current`);
	await ensureFlightStates(adapter, `${config.dpRoot}.airport`);
	await ensureFlightStates(adapter, `${config.dpRoot}.overflight`);
}

/**
 *
 */
export async function ensureFlightStates(adapter: AdapterLike, base: string): Promise<void> {
	await ensureChannel(adapter, base);

	const strings = [
		'.text',
		'.callsign',
		'.rawCallsign',
		'.cleanedCallsign',
		'.operationalCallsign',
		'.routeCallsign',
		'.hex',
		'.mode',
		'.flightPhase',
		'.directionText',
		'.trackDirectionText',

		'.modeVisText',

		'.windowPositionText',
		'.windowPositionClass',
		'.windowPositionSpeechText',

		'.probableRunway',
		'.probableRunwayText',

		'.probableRunway',
		'.probableRunwayText',

		'.airlineName',
		'.airlineIata',
		'.airlineIcao',

		'.originIata',
		'.destIata',
		'.originName',
		'.destName',

		'.originDisplayName',
		'.destDisplayName',
		'.departureAirport',
		'.approachAirport',

		'.routeText',
		'.routeTextLong',
		'.routeWarning',
		'.routeSource',

		'.routeDisplayText',
		'.routeCodesText',

		'.aircraftModel',
		'.aircraftType',
		'.registration',

		'.manufacturer',
		'.manufacturerLogoText',
		'.manufacturerLogoUrl',

		'.aircraftTypeText',
		'.aircraftSize',
		'.squawk',
		'.emergency',
		'.emergencyType',
		'.emergencyText',
		'.squawk',
		'.emergency',
		'.emergencyType',
		'.emergencyText',

		'.logoUrl',
		'.jetphotosUrl',
		'.jetphotosImageUrl',

		'.localLogoUrl',
		'.localImageUrl',
		'.finalImageUrl',

		'.specialText',
		'.specialLiveryTitle',
		'.specialLiveryDescription',
		'.specialLiveryFull',
		'.specialLiveryVisText',
		'.specialDisplayText',
		'.speechText',
	];

	for (const s of strings) {
		await ensureState(adapter, base + s, '', 'string', 'text');
	}

	const nums = [
		'.altitudeFt',
		'.speedKt',
		'.verticalRate',
		'.trackDeg',

		'.distHomeNm',
		'.distanceKm',
		'.distAirportNm',

		'.bearingHomeDeg',
		'.windowDiffDeg',

		'.probableRunwayHeading',
		'.probableRunwayDiffDeg',
		'.runwayConfidence',

		'.bearingAircraftToAirportDeg',
		'.bearingAirportToAircraftDeg',

		'.landingTrackDiffDeg',
		'.takeoffTrackDiffDeg',
		'.airportTrackDiffDeg',
	];

	for (const n of nums) {
		await ensureState(adapter, base + n, 0, 'number', 'value');
	}

	await ensureState(adapter, `${base}.routeReliable`, false, 'boolean', 'indicator');
	await ensureState(adapter, `${base}.isSpecial`, false, 'boolean', 'indicator');
	await ensureState(adapter, `${base}.isEmergency`, false, 'boolean', 'indicator');
	await ensureState(adapter, `${base}.speechTrigger`, false, 'boolean', 'button');
}

/**
 *
 */
export function trackDirectionText(degRaw: unknown): string {
	const deg = Number(degRaw);

	if (!Number.isFinite(deg)) {
		return '';
	}

	const normalized = ((deg % 360) + 360) % 360;

	const dirs = ['↑ North', '↗ Northeast', '→ East', '↘ Southeast', '↓ South', '↙ Southwest', '← West', '↖ Northwest'];

	const index = Math.round(normalized / 45) % 8;

	return dirs[index];
}

function getFlightPhase(a: any): string {
	const mode = String(a.mode || '').toUpperCase();
	const altFt = Number(a.altFt || a.altitudeFt || 0);
	const vr = Number(a.verticalRate || 0);
	const distAirportNm = Number(a.distAirportNm || 0);

	if (mode === 'LANDING') {
		if (altFt > 0 && altFt <= 1800) {
			return 'landing';
		}

		if (distAirportNm > 0 && distAirportNm <= 12) {
			return 'approach';
		}

		if (vr < -300) {
			return 'descent';
		}

		return 'approach';
	}

	if (mode === 'TAKEOFF') {
		if (altFt > 0 && altFt <= 1800) {
			return 'departure';
		}

		if (vr > 300) {
			return 'climb';
		}

		return 'departure';
	}

	if (mode === 'OVERFLIGHT') {
		if (vr < -500) {
			return 'descent';
		}

		if (vr > 500) {
			return 'climb';
		}

		return 'cruise';
	}

	if (vr < -500) {
		return 'descent';
	}

	if (vr > 500) {
		return 'climb';
	}

	if (altFt > 8000) {
		return 'cruise';
	}

	return 'unknown';
}

async function setForeignStateChanged(adapter: AdapterLike, id: string, value: any, ack = true): Promise<void> {
	try {
		const oldState = await adapter.getForeignStateAsync(id);

		if (oldState && oldState.val === value && oldState.ack === ack) {
			return;
		}
	} catch {
		// Wenn Lesen fehlschlägt, trotzdem schreiben
	}

	await adapter.setForeignStateAsync(id, value, ack);
}

export async function writeFlight(adapter: AdapterLike, base: string, a: Aircraft): Promise<void> {
	const routeCallsign = String(a.routeCallsign || a.callsign || '')
		.trim()
		.toUpperCase();
	const display = await buildDisplayInfo(adapter, adapter.config as JetFrameConfig, a);
	display.speechText = await buildSpeechTextForWrite(adapter, base, a, display);

	await setForeignStateChanged(adapter, `${base}.text`, buildMessage(a), true);

	const rawCallsign = String((a as any).rawCallsign || a.callsign || '').trim();
	const cleanedCallsign = String((a as any).cleanedCallsign || a.callsign || '')
		.trim()
		.replace(/\s+/g, '')
		.toUpperCase();

	await setForeignStateChanged(adapter, `${base}.callsign`, a.callsign || '', true);
	await setForeignStateChanged(adapter, `${base}.rawCallsign`, rawCallsign, true);
	await setForeignStateChanged(adapter, `${base}.cleanedCallsign`, cleanedCallsign, true);

	await setForeignStateChanged(
		adapter,
		`${base}.operationalCallsign`,
		a.operationalCallsign || a.callsign || '',
		true,
	);

	await setForeignStateChanged(adapter, `${base}.routeCallsign`, routeCallsign, true);
	await setForeignStateChanged(adapter, `${base}.hex`, a.hex || '', true);
	await setForeignStateChanged(adapter, `${base}.mode`, a.mode || '', true);
	await setForeignStateChanged(adapter, `${base}.flightPhase`, getFlightPhase(a), true);
	await setForeignStateChanged(adapter, `${base}.directionText`, a.directionText || '', true);

	await setForeignStateChanged(adapter, `${base}.modeVisText`, display.modeVisText, true);

	await setForeignStateChanged(adapter, `${base}.windowPositionText`, display.windowPositionText, true);
	await setForeignStateChanged(adapter, `${base}.windowPositionClass`, display.windowPositionClass, true);
	await setForeignStateChanged(adapter, `${base}.windowPositionSpeechText`, display.windowPositionSpeechText, true);

	await setForeignStateChanged(adapter, `${base}.probableRunway`, (a as any).probableRunway || '', true);
	await setForeignStateChanged(adapter, `${base}.probableRunwayText`, (a as any).probableRunwayText || '', true);
	await setForeignStateChanged(adapter, `${base}.probableRunwayHeading`, (a as any).probableRunwayHeading || 0, true);
	await setForeignStateChanged(adapter, `${base}.probableRunwayDiffDeg`, (a as any).probableRunwayDiffDeg || 0, true);
	await setForeignStateChanged(adapter, `${base}.runwayConfidence`, (a as any).runwayConfidence || 0, true);

	await setForeignStateChanged(adapter, `${base}.airlineName`, a.airlineName || '', true);
	await setForeignStateChanged(adapter, `${base}.airlineIata`, a.airlineIata || '', true);
	await setForeignStateChanged(adapter, `${base}.airlineIcao`, a.airlineIcao || '', true);

	await setForeignStateChanged(adapter, `${base}.originIata`, a.originIata || '', true);
	await setForeignStateChanged(adapter, `${base}.destIata`, a.destIata || '', true);
	await setForeignStateChanged(adapter, `${base}.originName`, a.originName || '', true);
	await setForeignStateChanged(adapter, `${base}.destName`, a.destName || '', true);

	await setForeignStateChanged(adapter, `${base}.originDisplayName`, display.originDisplayName, true);
	await setForeignStateChanged(adapter, `${base}.destDisplayName`, display.destDisplayName, true);

	await setForeignStateChanged(adapter, `${base}.departureAirport`, display.departureAirport, true);
	await setForeignStateChanged(adapter, `${base}.approachAirport`, display.approachAirport, true);

	await setForeignStateChanged(adapter, `${base}.routeText`, a.routeText || '', true);
	await setForeignStateChanged(adapter, `${base}.routeTextLong`, a.routeTextLong || '', true);
	await setForeignStateChanged(adapter, `${base}.routeReliable`, !!a.routeReliable, true);
	await setForeignStateChanged(adapter, `${base}.routeWarning`, a.routeWarning || '', true);
	await setForeignStateChanged(adapter, `${base}.routeSource`, a.routeSource || '', true);

	await setForeignStateChanged(adapter, `${base}.routeDisplayText`, display.routeDisplayText, true);
	await setForeignStateChanged(adapter, `${base}.routeCodesText`, display.routeCodesText, true);

	await setForeignStateChanged(adapter, `${base}.aircraftModel`, a.aircraftModel || '', true);
	await setForeignStateChanged(adapter, `${base}.aircraftType`, a.aircraftType || a.type || '', true);
	await setForeignStateChanged(adapter, `${base}.registration`, a.registration || '', true);

	await setForeignStateChanged(adapter, `${base}.manufacturer`, display.manufacturer, true);
	await setForeignStateChanged(adapter, `${base}.manufacturerLogoText`, display.manufacturerLogoText, true);
	await setForeignStateChanged(adapter, `${base}.manufacturerLogoUrl`, display.manufacturerLogoUrl, true);

	await setForeignStateChanged(adapter, `${base}.aircraftTypeText`, display.aircraftTypeText, true);
	await setForeignStateChanged(adapter, `${base}.aircraftSize`, display.aircraftSize, true);

	await setForeignStateChanged(adapter, `${base}.squawk`, a.squawk || '', true);
	await setForeignStateChanged(adapter, `${base}.emergency`, a.emergency || '', true);
	await setForeignStateChanged(adapter, `${base}.emergencyType`, a.emergencyType || '', true);
	await setForeignStateChanged(adapter, `${base}.emergencyText`, a.emergencyText || '', true);

	await setForeignStateChanged(adapter, `${base}.logoUrl`, a.logoUrl || '', true);
	await setForeignStateChanged(adapter, `${base}.jetphotosUrl`, a.jetphotosUrl || '', true);
	await setForeignStateChanged(adapter, `${base}.jetphotosImageUrl`, a.jetphotosImageUrl || '', true);

	const localLogoUrl = await keepExistingStringState(adapter, `${base}.localLogoUrl`, a.localLogoUrl);

	const localImageUrl = await keepExistingStringState(adapter, `${base}.localImageUrl`, a.localImageUrl);

	const preferredImage = a.jetphotosImageUrl || a.finalImageUrl || localImageUrl || '';

	const finalImageUrl = await keepExistingStringState(adapter, `${base}.finalImageUrl`, preferredImage);

	await setForeignStateChanged(adapter, `${base}.localLogoUrl`, localLogoUrl, true);
	await setForeignStateChanged(adapter, `${base}.localImageUrl`, localImageUrl, true);
	await setForeignStateChanged(adapter, `${base}.finalImageUrl`, finalImageUrl, true);

	await setForeignStateChanged(adapter, `${base}.altitudeFt`, Math.round(a.altFt || 0), true);
	await setForeignStateChanged(adapter, `${base}.speedKt`, Math.round(a.speedKt || 0), true);
	await setForeignStateChanged(adapter, `${base}.verticalRate`, Math.round(a.verticalRate || 0), true);
	await setForeignStateChanged(adapter, `${base}.trackDeg`, Math.round(a.trackDeg || 0), true);
	await setForeignStateChanged(adapter, `${base}.trackDirectionText`, trackDirectionText(a.trackDeg), true);

	await setForeignStateChanged(adapter, `${base}.distHomeNm`, a.distHomeNm || 0, true);

	await setForeignStateChanged(
		adapter,
		`${base}.distanceKm`,
		Math.round(Number(a.distHomeNm || 0) * 1.852 * 10) / 10,
		true,
	);
	await setForeignStateChanged(adapter, `${base}.distAirportNm`, round(a.distAirportNm || 0, 1), true);
	await setForeignStateChanged(adapter, `${base}.bearingHomeDeg`, round(a.bearingHomeDeg || 0, 1), true);
	await setForeignStateChanged(adapter, `${base}.windowDiffDeg`, round(a.windowDiffDeg || 0, 1), true);

	await setForeignStateChanged(
		adapter,
		`${base}.bearingAircraftToAirportDeg`,
		round(a.bearingAircraftToAirportDeg || 0, 1),
		true,
	);
	await setForeignStateChanged(
		adapter,
		`${base}.bearingAirportToAircraftDeg`,
		round(a.bearingAirportToAircraftDeg || 0, 1),
		true,
	);
	await setForeignStateChanged(adapter, `${base}.landingTrackDiffDeg`, round(a.landingTrackDiffDeg || 0, 1), true);
	await setForeignStateChanged(adapter, `${base}.takeoffTrackDiffDeg`, round(a.takeoffTrackDiffDeg || 0, 1), true);
	await setForeignStateChanged(adapter, `${base}.airportTrackDiffDeg`, round(a.airportTrackDiffDeg || 0, 1), true);

	await setForeignStateChanged(adapter, `${base}.specialText`, a.specialText || '', true);
	await setForeignStateChanged(adapter, `${base}.specialLiveryTitle`, a.specialLiveryTitle || '', true);
	await setForeignStateChanged(adapter, `${base}.specialLiveryDescription`, a.specialLiveryDescription || '', true);
	await setForeignStateChanged(adapter, `${base}.specialLiveryFull`, a.specialLiveryFull || '', true);
	await setForeignStateChanged(adapter, `${base}.specialLiveryVisText`, a.specialLiveryVisText || '', true);
	await setForeignStateChanged(adapter, `${base}.specialDisplayText`, display.specialDisplayText, true);
	await setForeignStateChanged(adapter, `${base}.speechText`, display.speechText, true);

	await setForeignStateChanged(adapter, `${base}.isSpecial`, !!a.isSpecial, true);
	await setForeignStateChanged(adapter, `${base}.isEmergency`, !!a.isEmergency, true);

	await maybeTriggerSpeech(adapter, base, a, display.speechText);
}

/**
 *
 */
export async function clearFlight(adapter: AdapterLike, base: string): Promise<void> {
	const strings = [
		'.text',
		'.callsign',
		'.operationalCallsign',
		'.routeCallsign',
		'.hex',
		'.mode',
		'.directionText',

		'.modeVisText',

		'.windowPositionText',
		'.windowPositionClass',
		'.windowPositionSpeechText',

		'.airlineName',
		'.airlineIata',
		'.airlineIcao',

		'.originIata',
		'.destIata',
		'.originName',
		'.destName',

		'.originDisplayName',
		'.destDisplayName',
		'.departureAirport',
		'.approachAirport',

		'.routeText',
		'.routeTextLong',
		'.routeWarning',
		'.routeSource',

		'.routeDisplayText',
		'.routeCodesText',

		'.aircraftModel',
		'.aircraftType',
		'.registration',

		'.manufacturer',
		'.manufacturerLogoText',
		'.manufacturerLogoUrl',

		'.aircraftTypeText',
		'.aircraftSize',

		'.logoUrl',
		'.jetphotosUrl',
		'.jetphotosImageUrl',

		'.localLogoUrl',
		'.localImageUrl',
		'.finalImageUrl',

		'.specialText',
		'.specialLiveryTitle',
		'.specialLiveryDescription',
		'.specialLiveryFull',
		'.specialLiveryVisText',
		'.specialDisplayText',
		'.speechText',
	];

	for (const s of strings) {
		await setForeignStateChanged(adapter, base + s, '', true);
	}

	const nums = [
		'.altitudeFt',
		'.speedKt',
		'.verticalRate',
		'.trackDeg',

		'.distHomeNm',
		'.distAirportNm',

		'.bearingHomeDeg',
		'.windowDiffDeg',

		'.probableRunwayHeading',
		'.probableRunwayDiffDeg',
		'.runwayConfidence',

		'.bearingAircraftToAirportDeg',
		'.bearingAirportToAircraftDeg',

		'.landingTrackDiffDeg',
		'.takeoffTrackDiffDeg',
		'.airportTrackDiffDeg',
	];

	for (const n of nums) {
		await setForeignStateChanged(adapter, base + n, 0, true);
	}

	await setForeignStateChanged(adapter, `${base}.routeReliable`, false, true);
	await setForeignStateChanged(adapter, `${base}.isSpecial`, false, true);
	await setForeignStateChanged(adapter, `${base}.isEmergency`, false, true);
	await setForeignStateChanged(adapter, `${base}.speechTrigger`, false, true);
}

async function buildDisplayInfo(
	adapter: AdapterLike,
	config: JetFrameConfig,
	a: Aircraft,
): Promise<Record<string, string>> {
	const originDisplayName = cityOnly(a.originName) || String(a.originIata || '').trim() || '—';

	const destDisplayName = cityOnly(a.destName) || String(a.destIata || '').trim() || '—';

	const routeDisplayText = `${originDisplayName} → ${destDisplayName}`;

	const routeCodesText = `${a.originIata || '—'} → ${a.destIata || '—'}`;

	const configuredAirportLabel = airportLabel(
		config.airport?.name || config.airport?.iata || '',
		config.airport?.iata || '',
	);

	const mode = String(a.mode || '').toUpperCase();

	const departureAirport =
		airportLabel(originDisplayName, a.originIata) || (mode === 'TAKEOFF' ? configuredAirportLabel : '');

	const approachAirport =
		airportLabel(destDisplayName, a.destIata) || (mode === 'LANDING' ? configuredAirportLabel : '');

	const modeVisText = modeVisTextFromFlight(a, originDisplayName, destDisplayName);

	const window = windowPositionInfo(a);

	const aircraft = await aircraftDisplayInfo(adapter, config, a);

	const specialDisplayText = String(a.specialLiveryVisText || a.specialLiveryFull || a.specialText || '').trim();

	// Note: speech text is intentionally NOT computed here. writeFlight() always
	// overwrites display.speechText with buildSpeechTextForWrite(), which
	// supports a user-configurable template — computing it here as well would
	// be wasted work.

	return {
		modeVisText,

		windowPositionText: window.text,
		windowPositionClass: window.className,
		windowPositionSpeechText: window.speechText,

		originDisplayName,
		destDisplayName,
		departureAirport,
		approachAirport,
		routeDisplayText,
		routeCodesText,

		specialDisplayText,

		manufacturer: aircraft.manufacturer,
		manufacturerLogoText: aircraft.manufacturerLogoText,
		manufacturerLogoUrl: aircraft.manufacturerLogoUrl,
		aircraftTypeText: aircraft.aircraftTypeText,
		aircraftSize: aircraft.aircraftSize,
	};
}

function airportLabel(name: unknown, iata: unknown): string {
	const n = (typeof name === 'string' ? name : '').trim();
	const c = (typeof iata === 'string' ? iata : '').trim().toUpperCase();

	if (n && c && n !== '—') {
		return `${n} (${c})`;
	}

	if (c) {
		return c;
	}

	if (n && n !== '—') {
		return n;
	}

	return '';
}

function modeVisTextFromFlight(a: Aircraft, originDisplayName: string, destDisplayName: string): string {
	const mode = String(a.mode || '').toUpperCase();

	if (mode === 'TAKEOFF') {
		return `🛫 Takeoff ${originDisplayName !== '—' ? originDisplayName : ''}`.trim();
	}

	if (mode === 'LANDING') {
		return `🛬 Landing ${destDisplayName !== '—' ? destDisplayName : ''}`.trim();
	}

	if (mode === 'OVERFLIGHT') {
		return '🛩️ Overflight';
	}

	return '✈️ Flight';
}

function windowPositionInfo(a: Aircraft): {
	text: string;
	className: string;
	speechText: string;
} {
	const bearing = Number(a.bearingHomeDeg || 0);
	const diff = Number(a.windowDiffDeg || 0);

	if (!bearing && !diff) {
		return {
			text: '↗️ Position unknown',
			className: 'side',
			speechText: 'am Fenster',
		};
	}

	const abs = Math.abs(diff);

	if (abs <= 8) {
		return {
			text: '⬆️ direkt vor dem Fenster',
			className: 'center',
			speechText: 'direkt vor dem Fenster',
		};
	}

	if (diff < 0) {
		return {
			text: `⬅️ links vom Fenster · ${Math.round(abs)}°`,
			className: 'side',
			speechText: 'links vom Fenster',
		};
	}

	return {
		text: `➡️ rechts vom Fenster · ${Math.round(abs)}°`,
		className: 'side',
		speechText: 'rechts vom Fenster',
	};
}

async function aircraftDisplayInfo(
	adapter: AdapterLike,
	config: JetFrameConfig,
	a: Aircraft,
): Promise<{
	manufacturer: string;
	manufacturerLogoText: string;
	manufacturerLogoUrl: string;
	aircraftTypeText: string;
	aircraftSize: string;
}> {
	const raw = String(a.aircraftModel || a.aircraftType || a.type || '').trim();

	const type = String(a.aircraftType || a.type || '')
		.trim()
		.toUpperCase();

	const model = String(a.aircraftModel || '')
		.trim()
		.toUpperCase();

	const all = `${type} ${model} ${raw}`.toUpperCase();

	let manufacturer = 'Flugzeug';
	let manufacturerLogoText = '✈';
	let aircraftTypeText = raw || type || '—';

	if (all.includes('AIRBUS') || /^A\d/.test(type)) {
		manufacturer = 'Airbus';
		manufacturerLogoText = 'A';

		if (type && /^A\d/.test(type)) {
			aircraftTypeText = `Airbus ${type}`;
		}
	} else if (all.includes('BOEING') || /^B\d/.test(type)) {
		manufacturer = 'Boeing';
		manufacturerLogoText = 'B';

		if (type && /^B\d/.test(type)) {
			aircraftTypeText = `Boeing ${type}`;
		}
	} else if (all.includes('EMBRAER') || /^E\d/.test(type) || all.includes('E-JET')) {
		manufacturer = 'Embraer';
		manufacturerLogoText = 'E';

		if (type) {
			aircraftTypeText = `Embraer ${type}`;
		}
	} else if (all.includes('ATR') || /^AT\d/.test(type)) {
		manufacturer = 'ATR';
		manufacturerLogoText = 'ATR';

		if (type) {
			aircraftTypeText = `ATR ${type}`;
		}
	} else if (all.includes('DASSAULT') || all.includes('FALCON')) {
		manufacturer = 'Dassault';
		manufacturerLogoText = 'D';

		if (type) {
			aircraftTypeText = `Dassault ${type}`;
		}
	} else if (all.includes('LOCKHEED') || all.includes('HERCULES') || all.includes('C130')) {
		manufacturer = 'Lockheed';
		manufacturerLogoText = 'L';

		if (type) {
			aircraftTypeText = `Lockheed ${type}`;
		}
	} else if (all.includes('HONDA') || all.includes('HONDAJET')) {
		manufacturer = 'Honda';
		manufacturerLogoText = 'H';

		if (type) {
			aircraftTypeText = `HondaJet ${type}`;
		}
	} else if (all.includes('BOMBARDIER') || all.includes('CRJ') || all.includes('CSERIES') || all.includes('A220')) {
		manufacturer = all.includes('A220') ? 'Airbus' : 'Bombardier';
		manufacturerLogoText = manufacturer === 'Airbus' ? 'A' : 'B';

		if (type) {
			aircraftTypeText = `${manufacturer} ${type}`;
		}
	}

	const aircraftSize = aircraftSizeLabel(all);

	let manufacturerLogoUrl = findConfiguredManufacturerLogo(config, manufacturer, all);

	if (manufacturerLogoUrl && config.cacheExternalImages) {
		manufacturerLogoUrl = await cacheExternalLogoUrl(
			adapter,
			manufacturerLogoUrl,
			manufacturer,
			MANUFACTURER_LOGO_CACHE_DIR,
			adapter.log.debug.bind(adapter.log),
			adapter.log.warn.bind(adapter.log),
		);
	}

	return {
		manufacturer,
		manufacturerLogoText,
		manufacturerLogoUrl,
		aircraftTypeText,
		aircraftSize,
	};
}

function findConfiguredManufacturerLogo(config: JetFrameConfig, manufacturer: string, allText: string): string {
	if (!config.externalManufacturerLogos) {
		return '';
	}

	const entries = parseManufacturerLogoConfig(config.manufacturerLogoUrls);

	if (!entries.length) {
		return '';
	}

	const haystack = `${manufacturer} ${allText}`.toUpperCase();

	for (const entry of entries) {
		if (haystack.includes(entry.key)) {
			return entry.url;
		}
	}

	return '';
}

function parseManufacturerLogoConfig(raw: string): Array<{ key: string; url: string }> {
	const text = String(raw || '').trim();

	if (!text) {
		return [];
	}

	try {
		const obj = JSON.parse(text) as Record<string, string>;

		if (obj && typeof obj === 'object' && !Array.isArray(obj)) {
			return Object.entries(obj)
				.map(([key, url]) => ({
					key: String(key || '')
						.trim()
						.toUpperCase(),
					url: String(url || '').trim(),
				}))
				.filter(entry => !!entry.key && /^https?:\/\//i.test(entry.url));
		}
	} catch {
		// Fallback: Zeilenformat KEY=https://...
	}

	return text
		.split(/\r?\n/)
		.map(line => line.trim())
		.filter(Boolean)
		.map(line => {
			const idx = line.indexOf('=');

			if (idx < 1) {
				return null;
			}

			return {
				key: line.slice(0, idx).trim().toUpperCase(),
				url: line.slice(idx + 1).trim(),
			};
		})
		.filter((entry): entry is { key: string; url: string } => !!entry?.key && /^https?:\/\//i.test(entry.url));
}

function aircraftSizeLabel(allText: string): string {
	const all = String(allText || '')
		.toUpperCase()
		.replace(/[\s_-]/g, '');

	// Superjumbo / Jumbo
	if (/A38|A380|A388/.test(all)) {
		return 'Superjumbo';
	}
	if (/B74|B747|B741|B742|B743|B744|B748/.test(all)) {
		return 'Jumbo';
	}

	// Heavy Cargo / Military Transport
	if (/AN124|AN225|C5M|GALAXY|C17|C17A|GLOBEMASTER/.test(all)) {
		return 'Heavy Cargo';
	}
	if (/A400|A400M|C130|HERCULES|KC135|KC46|E3|E7/.test(all)) {
		return 'Military';
	}

	// Widebody
	if (
		/A300|A310|A330|A332|A333|A338|A339/.test(all) ||
		/A340|A342|A343|A345|A346/.test(all) ||
		/A350|A359|A35K|A351/.test(all) ||
		/B757|B752|B753/.test(all) ||
		/B767|B762|B763|B764/.test(all) ||
		/B777|B772|B773|B77W|B778|B779|B77L|B77F/.test(all) ||
		/B787|B788|B789|B78X/.test(all) ||
		/DC10|MD11|IL86|IL96|L1011/.test(all)
	) {
		return 'Widebody';
	}

	// Cargo
	if (/A300F|A330F|B763F|B752F|B733F|B734F|B738F|AN12|AN26/.test(all)) {
		return 'Cargo';
	}

	// Narrowbody
	if (
		/A220|A221|A223|BCS1|BCS3|CS100|CS300/.test(all) ||
		/A318|A319|A320|A321|A20N|A21N/.test(all) ||
		/B707|B717|B727|B737|B731|B732|B733|B734|B735|B736|B738|B739|B38M|B39M/.test(all) ||
		/DC8|DC9|MD80|MD81|MD82|MD83|MD87|MD88|MD90/.test(all) ||
		/TU134|TU154|TU204|TU214|C919|ARJ21|MC21/.test(all)
	) {
		return 'Narrowbody';
	}

	// Regional
	if (
		/CRJ|CRJ1|CRJ2|CRJ7|CRJ9|CRJX|CRJ100|CRJ200|CRJ700|CRJ900|CRJ1000/.test(all) ||
		/ERJ|E135|E140|E145|E170|E175|E190|E195|E290|E295/.test(all) ||
		/AT42|AT43|AT45|AT46|AT72|AT75|AT76|ATR/.test(all) ||
		/DH8|DHC8|Q200|Q300|Q400/.test(all) ||
		/SF34|SF340|SB20|F50|F70|F100|DO228|DO328|RJ70|RJ85|RJ100/.test(all)
	) {
		return 'Regional';
	}

	// Business Jet
	if (
		/GLEX|GLF|G280|G450|G500|G550|G650|G700/.test(all) ||
		/CL30|CL35|CL60|GLOBAL|CHALLENGER/.test(all) ||
		/FALCON|FA7X|FA8X|FA50|FA90|F2TH|F900|F2000/.test(all) ||
		/CITATION|C25A|C25B|C25C|C56X|C68A|C700|LJ35|LJ45|LJ60|LJ75/.test(all) ||
		/LEGACY|PRAETOR|PHENOM|E50P|E55P|HA420|PC24/.test(all)
	) {
		return 'Business Jet';
	}

	// General Aviation
	if (/C172|C182|C206|C208|PA28|PA34|BE20|BE9L|PC12|DA40|DA42/.test(all)) {
		return 'General Aviation';
	}

	// Helicopter
	if (/EC135|EC145|H135|H145|H160|AW109|AW139|AW169|AW189|S76|S92|UH60|CH47|MI8|KA32/.test(all)) {
		return 'Helicopter';
	}

	// Military Jet / Bomber
	if (
		/F14|F15|F16|F18|F22|F35|EUROFIGHTER|TYPHOON|RAFALE|GRIPEN|MIRAGE|SU27|SU30|SU35|MIG29|B1|B2|B52|TU95|TU160/.test(
			all,
		)
	) {
		return 'Military';
	}

	return 'Unknown';
}

async function maybeTriggerSpeech(adapter: AdapterLike, base: string, a: Aircraft, speechText: string): Promise<void> {
	if (!base.endsWith('.current')) {
		return;
	}

	const root = base.split('.').slice(0, -1).join('.');

	let speechMode = 'browser';

	try {
		const st = await adapter.getForeignStateAsync(`${root}.speechMode`);
		speechMode = String(st?.val || 'browser');
	} catch {
		speechMode = 'browser';
	}

	if (speechMode !== 'external' && speechMode !== 'both') {
		return;
	}

	const key = [
		String(a.callsign || ''),
		String(a.routeCallsign || ''),
		String(a.registration || ''),
		String(speechText || ''),
	].join('|');

	if (!key || LAST_SPEECH_TRIGGER[base] === key) {
		return;
	}

	LAST_SPEECH_TRIGGER[base] = key;

	await adapter.setForeignStateAsync(`${base}.speechTrigger`, true, true);

	adapter.setTimeout(() => {
		adapter.setForeignStateAsync(`${base}.speechTrigger`, false, true).catch(() => {});
	}, 500);
}

async function buildSpeechTextForWrite(
	adapter: AdapterLike,
	base: string,
	a: Aircraft,
	display: Record<string, string>,
): Promise<string> {
	const root = base.split('.').slice(0, -1).join('.');

	let template =
		'{modeSpeechText}: {airlineName} {bestCallsign} {routeDirectionText} {routeOtherAirport} in {altitudeFt} ft. {windowPositionSpeechText}.';

	try {
		const st = await adapter.getForeignStateAsync(`${root}.speechTemplate`);
		if (st?.val) {
			template = String(st.val);
		}
	} catch {
		// State not readable — fall back to the default template defined above.
	}

	return buildSpeechTextFromTemplate(a, display, template);
}

function buildSpeechTextFromTemplate(a: Aircraft, display: Record<string, string>, template: string): string {
	const mode = String(a.mode || '').toUpperCase();

	let modeSpeechText = 'Flug';
	let routeDirectionText = 'von';
	let routeOtherAirport = display.originDisplayName || display.destDisplayName || '';

	if (mode === 'LANDING') {
		modeSpeechText = 'Landung';
		routeDirectionText = 'aus';
		routeOtherAirport = display.originDisplayName || '';
	}

	if (mode === 'TAKEOFF') {
		modeSpeechText = 'Start';
		routeDirectionText = 'nach';
		routeOtherAirport = display.destDisplayName || '';
	}

	if (mode === 'OVERFLIGHT') {
		modeSpeechText = 'Überflug';
		routeDirectionText = 'von';
		routeOtherAirport = display.routeDisplayText || '';
	}

	const bestCallsign = String(a.routeCallsign || a.callsign || '').trim();

	const values: Record<string, string> = {
		modeSpeechText,
		routeDirectionText,
		routeOtherAirport,
		bestCallsign,

		airlineName: String(a.airlineName || 'Unbekannte Airline'),
		callsign: String(a.callsign || ''),
		operationalCallsign: String(a.operationalCallsign || a.callsign || ''),
		routeCallsign: String(a.routeCallsign || a.callsign || ''),
		originDisplayName: display.originDisplayName || '',
		destDisplayName: display.destDisplayName || '',
		routeDisplayText: display.routeDisplayText || '',
		routeCodesText: display.routeCodesText || '',
		aircraftTypeText: display.aircraftTypeText || '',
		aircraftSize: display.aircraftSize || '',
		registration: String(a.registration || ''),
		altitudeFt: String(Math.round(a.altFt || 0)),
		speedKt: String(Math.round(a.speedKt || 0)),
		verticalRate: String(Math.round(a.verticalRate || 0)),
		trackDeg: String(Math.round(a.trackDeg || 0)),
		windowPositionSpeechText: display.windowPositionSpeechText || '',
		specialDisplayText: display.specialDisplayText || '',
	};

	return String(template || '')
		.replace(/\{([a-zA-Z0-9_]+)\}/g, (_match, key) => values[key] || '')
		.replace(/\s+/g, ' ')
		.replace(/\s+\./g, '.')
		.trim();
}

function cityOnly(name: unknown): string {
	const v = (typeof name === 'string' ? name : '')
		.replace(/\bAirport\b/gi, '')
		.replace(/\bInternational\b/gi, '')
		.replace(/\bIntl\b/gi, '')
		.replace(/\bFlughafen\b/gi, '')
		.replace(/\bFort Worth\b/gi, '')
		.replace(/\bMain\b/gi, '')
		.replace(/\s+/g, ' ')
		.trim();

	if (v === 'Frankfurt am') {
		return 'Frankfurt';
	}

	return v;
}

function buildMessage(a: Aircraft): string {
	const lines: string[] = [];
	const routeCallsign = String(a.routeCallsign || a.callsign || '')
		.trim()
		.toUpperCase();

	lines.push('✈️ JetFrame');
	lines.push('');

	lines.push(`${a.icon || '✈️'} ${modeText(a.mode || '')}`);
	lines.push(`Flight: ${a.callsign || a.hex || 'unknown'}`);

	if (routeCallsign) {
		lines.push(`Route via: ${routeCallsign}`);
	}

	if (a.airlineName) {
		lines.push(`Airline: ${a.airlineName}`);
	}

	if (a.routeTextLong) {
		lines.push(`Route: ${a.routeTextLong}`);
	} else if (a.routeText) {
		lines.push(`Route: ${a.routeText}`);
	} else if (a.routeWarning) {
		lines.push(`Route: ${a.routeWarning}`);
	} else if (a.directionText) {
		lines.push(`Direction: ${a.directionText}`);
	}

	if (a.routeSource) {
		lines.push(`Source: ${a.routeSource}`);
	}

	if (a.aircraftModel) {
		lines.push(`Aircraft: ${a.aircraftModel}`);
	} else if (a.aircraftType || a.type) {
		lines.push(`Type: ${a.aircraftType || a.type}`);
	}

	if (a.registration) {
		lines.push(`Reg.: ${a.registration}`);
	}

	lines.push('');
	lines.push(`Altitude: ${Math.round(a.altFt || 0)} ft`);
	lines.push(`Speed: ${Math.round(a.speedKt || 0)} kt`);
	lines.push(`Climb rate: ${Math.round(a.verticalRate || 0)} ft/min`);
	lines.push(`Heading: ${Math.round(a.trackDeg || 0)}°`);

	const specialDisplayText = a.specialLiveryVisText || a.specialLiveryFull || a.specialText || '';

	if (specialDisplayText) {
		lines.push('');
		lines.push(`${a.isSpecial ? '⭐ Special: ' : 'ℹ️ Info: '}${specialDisplayText}`);
	}
	return lines.join('\n');
}

function modeText(mode: string): string {
	if (mode === 'LANDING') {
		return 'Landing';
	}
	if (mode === 'TAKEOFF') {
		return 'Takeoff';
	}
	if (mode === 'OVERFLIGHT') {
		return 'Overflight';
	}
	return 'Flight';
}

/**
 *
 */
export async function ensureStates(adapter: AdapterLike, config: JetFrameConfig): Promise<void> {
	await ensureBaseStates(adapter, config);
}

async function keepExistingStringState(adapter: AdapterLike, id: string, value: unknown): Promise<string> {
	const next = (typeof value === 'string' ? value : '').trim();

	if (next) {
		return next;
	}

	try {
		const oldState = await adapter.getForeignStateAsync(id);
		return String(oldState?.val || '').trim();
	} catch {
		return '';
	}
}
